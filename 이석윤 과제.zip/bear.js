function setup() {
  createCanvas(800, 800);
  strokeWeight(3)
}
function a(){
  noStroke();
  ellipse(170,230,50);
}
function draw() {
  stroke(0);
  fill(255,182,193);
  ellipse(100,100,100)
  ellipse(400,100,100);
  fill(255);
  ellipse(100,100,50);
  ellipse(400,100,50);
  fill(255,182,193);
  ellipse(250,250,400);
  fill(0);
  ellipse(200,200,20);
  ellipse(300,200,20);
  noFill();
  arc(250,230,30,30,PI,TWO_PI);
  fill(255,105,180);
  noStroke();
  ellipse(170,230,55);
  ellipse(330,230,55);
  stroke(0);
  noFill();
  arc(250,130,250,280,QUARTER_PI,PI-QUARTER_PI);
}